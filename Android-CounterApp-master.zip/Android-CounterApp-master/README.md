# Counter Application

#### Clone the project

```sh
https://github.com/Computer-Lab-Space/Android-CounterApp.git
```

#### Implementation Video Link
> [Counter App - Implementation](https://youtu.be/74DL6imi658)
>
> Please do Share, Like, Subscribe and support us, finally hit the bell icon.

#### Requirement
Write a program to create an activity with two buttons START and STOP. On Pressing of the
START button, the activity must start the counter by displaying the numbers from One and the
counter must keep on counting until the STOP button is pressed. Display the counter value in a
TextView control.

[Counter App Wiremock](https://github.com/Computer-Lab-Space/Android-CounterApp/blob/develop/app/src/main/res/drawable/Counter_App_requirement.png)
